import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

import static org.junit.Assert.assertEquals;

/**
 * Class for the test for the MarbleSolitaireTextView.
 */
public class MarbleSolitaireTextViewTest {
  MarbleSolitaireModel model1;

  MarbleSolitaireModel model2;

  MarbleSolitaireView view1;

  MarbleSolitaireView view2;


  /**
   * Initialized data for the test of the MarbleSolitaireTextView Methods.
   */
  @Before
  public void initData() {
    model1 = new EnglishSolitaireModel();

    model2 = new EnglishSolitaireModel(5, 6, 6);

    view1 = new MarbleSolitaireTextView(model1);

    view2 = new MarbleSolitaireTextView(model2);

  }



  @Test public void toStringWorks() {
    assertEquals("    O O O\n" +
                          "    O O O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O O O O O\n" +
                          "    O O O\n" +
                          "    O O O", view1.toString());
  }


  @Test public void toStringWorks2() {
    assertEquals("        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O", view2.toString());
  }


}