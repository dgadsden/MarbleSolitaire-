package cs3500.marblesolitaire.view;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * Class that represents the view of a MarbleSolitaireView.
 */
public class MarbleSolitaireTextView implements MarbleSolitaireView {

  private MarbleSolitaireModelState board;

  /**
   * Constructor that takes in a MarbleSolitaireModelState so that it can to viewed.
   * @param board the board of a Marble Solitaire game.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState board) {
    this.board = board;
  }

  /**
   * Function that turns a MarbleSolitaireModelState Board into string for viewing purposes.
   * @return the board as a string.
   */
  public String toString() {
    StringBuilder view = new StringBuilder();
    for (int i = 0; i < board.getBoardSize(); i++) {
      for (int j = 0; j < board.getBoardSize(); j++) {
        if (board.getSlotAt(i, j).equals(MarbleSolitaireModelState.SlotState.Invalid)) {
          view.append(" ");
        } else if (board.getSlotAt(i, j).equals(MarbleSolitaireModelState.SlotState.Marble)) {
          view.append("O");
        } else if (board.getSlotAt(i, j).equals(MarbleSolitaireModelState.SlotState.Empty)) {
          view.append("_");
        }
        if ((j == board.getBoardSize() - 1 || board.getSlotAt(i, j + 1)
                == MarbleSolitaireModelState.SlotState.Invalid)
                && board.getSlotAt(i, j) != MarbleSolitaireModelState.SlotState.Invalid) {
          view.append("\n");
          break;
        } else {
          view.append(" ");
        }
      }
    }
    if (view.length() > 0) {
      return view.substring(0, view.length() - 1);
    } else {
      return view.substring(0, view.length());
    }
  }
}
