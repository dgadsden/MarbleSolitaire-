import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;

import static org.junit.Assert.assertEquals;

public class EuroAndTriModelTest {

  MarbleSolitaireModel euroModelDefault;

  MarbleSolitaireModel euroModelSideLength5;

  MarbleSolitaireModel euroModelCustomEmptySlot;

  MarbleSolitaireModel triangleModelDefault;

  MarbleSolitaireModel  triangleModelSideLength5;

  MarbleSolitaireModel  triangleModelCustomEmptySlot;

@Before public void initData() {
  euroModelDefault = new EuropeanSolitaireModel();

  euroModelSideLength5 = new EuropeanSolitaireModel(5);

  euroModelCustomEmptySlot = new EuropeanSolitaireModel(4,4);


  triangleModelDefault = new EuropeanSolitaireModel();

  triangleModelSideLength5 = new EuropeanSolitaireModel(5);

  triangleModelCustomEmptySlot = new EuropeanSolitaireModel(4,4);

}

  // Euro Model Test:
  // test for the constructors
  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsNegativeEmptySlotRows() {
    new EuropeanSolitaireModel(-3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsNegativeEmptySlotCols() {
    new EuropeanSolitaireModel(3, -3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsNegativeEmptySlot() {
    new EuropeanSolitaireModel(-3, -3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot1() {
    new EuropeanSolitaireModel(0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot2() {
    new EuropeanSolitaireModel(1, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot3() {
    new EuropeanSolitaireModel(5, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot4() {
    new EuropeanSolitaireModel(6, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot5() {
    new EuropeanSolitaireModel(0, 1);
  }



  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot8() {
    new EuropeanSolitaireModel(6, 1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot9() {
    new EuropeanSolitaireModel(0, 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot12() {
    new EuropeanSolitaireModel(6, 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot13() {
    new EuropeanSolitaireModel(0, 6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot14() {
    new EuropeanSolitaireModel(1, 6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot15() {
    new EuropeanSolitaireModel(5, 6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsInvalidEmptySlot16() {
    new EuropeanSolitaireModel(6, 6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsEvenArmThickness() {
    new EuropeanSolitaireModel(2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsNegativeArmThickness() {
    new EuropeanSolitaireModel(-5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsNegative1() {
    new EuropeanSolitaireModel(-3, 3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsNegative2() {
    new EuropeanSolitaireModel(3, -3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsNegative3() {
    new EuropeanSolitaireModel(3, 3, -3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void esmlConstructorDisallowsEven1() {
    new EuropeanSolitaireModel(4, 3, 3);
  }

  // test for get board size
  @Test
  public void getBoardSizeWorks() {
    assertEquals(euroModelDefault.getBoardSize(), 7);
  }

  @Test
  public void getBoardSizeWorksWithCustomBoard() {
    assertEquals(euroModelCustomEmptySlot.getBoardSize(), 7);
  }

  @Test
  public void getBoardSizeWorksWithSizeOtherThan3() {
    assertEquals(euroModelSideLength5.getBoardSize(), 13);
  }

  // test for getSlotAt
  @Test
  public void getSlotAtworksFindEmpty() {
    assertEquals(euroModelDefault.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
  }

  @Test
  public void getSlotAtworksFindMarble() {
    assertEquals(euroModelDefault.getSlotAt(0, 2), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void getSlotAtworksFindInvalid() {
    assertEquals(euroModelDefault.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Invalid);
  }

  @Test
  public void getSlotAtworksWithCustomFindEmpty() {
    assertEquals(euroModelCustomEmptySlot.getSlotAt(4, 4),
            MarbleSolitaireModelState.SlotState.Empty);
  }

  @Test
  public void getSlotAtworksWithCustomFindMarble() {
    assertEquals(euroModelCustomEmptySlot.getSlotAt(0, 3), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void getSlotAtworksWithCustomFindInvalid() {
    assertEquals(euroModelCustomEmptySlot.getSlotAt(0, 6), MarbleSolitaireModelState.SlotState.Invalid);
  }

  @Test
  public void getSlotAtworksWithCustom2FindEmpty() {
    assertEquals(euroModelSideLength5.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Empty);
  }

  @Test
  public void getSlotAtworksWithCustom2FindMarble() {
    assertEquals(euroModelSideLength5.getSlotAt(5, 6), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void getSlotAtworksWithCustom2FindInvalid() {
    assertEquals(euroModelSideLength5.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Invalid);
  }

  //invalid getSlots
  @Test(expected = IllegalArgumentException.class)
  public void getSlotThrowWhenOutofBounds() {
    euroModelSideLength5.getSlotAt(-1, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void getSlotThrowWhenOutofBounds2() {
    euroModelDefault.getSlotAt(0, 100);
  }

  //test for getScore no move
  @Test
  public void getScoreWorksNoMoves() {
    assertEquals(euroModelDefault.getScore(), 36);
  }

  @Test
  public void getScoreWorksNoMoves2() {
    assertEquals(euroModelCustomEmptySlot.getScore(), 36);
  }

  @Test
  public void getScoreWorksNoMoves3() {
    assertEquals(euroModelSideLength5.getScore(), 128);
  }

  //test getScore after moves;
  @Test
  public void getScoreWorksWithMoves() {

    euroModelDefault.move(3, 5, 3, 3);
    assertEquals(euroModelDefault.getScore(), 35);

  }

  @Test
  public void getScoreWorksWithMoves2() {

    euroModelDefault.move(3, 5, 3, 3);
    euroModelDefault.move(3, 2, 3, 4);

    assertEquals(euroModelDefault.getScore(), 34);

  }

  //test for move
  @Test
  public void moveWorkAndGetScore() {
    assertEquals(euroModelDefault.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(euroModelDefault.getSlotAt(3, 4), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(euroModelDefault.getSlotAt(3, 5), MarbleSolitaireModelState.SlotState.Marble);
    // move marble to empty middle slot
    euroModelDefault.move(3, 5, 3, 3);
    assertEquals(euroModelDefault.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(euroModelDefault.getSlotAt(3, 4), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(euroModelDefault.getSlotAt(3, 5), MarbleSolitaireModelState.SlotState.Empty);

  }

  @Test
  public void moveWorkWithCustom() {
    assertEquals(euroModelSideLength5.getSlotAt(4, 6), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(euroModelSideLength5.getSlotAt(5, 6), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(euroModelSideLength5.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Empty);
    // move marble to empty middle slot
    euroModelSideLength5.move(4, 6, 6, 6);
    assertEquals(euroModelSideLength5.getSlotAt(4, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(euroModelSideLength5.getSlotAt(5, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(euroModelSideLength5.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Marble);

  }

  //invalid moves
  @Test(expected = IllegalArgumentException.class)
  public void moveThrowsMoveEmpty() {
    euroModelDefault.move(3, 3, 3, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void moveThrowsMoveInvalid() {
    euroModelDefault.move(0, 0, 3, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void moveThrowsMoveMarbletoMarble() {
    euroModelDefault.move(1, 2, 3, 2);
  }


  @Test(expected = IllegalArgumentException.class)
  public void moveThrowsMoveMarbletoFar() {
    euroModelDefault.move(0, 3, 3, 3);
  }


  //test for isGameOver
  @Test
  public void gameIsNotOver() {
    assertEquals(euroModelDefault.isGameOver(), false);
  }

  @Test
  public void gameIsNotOver2() {
    euroModelDefault.move(1, 3, 3, 3);
    assertEquals(euroModelDefault.isGameOver(), false);
  }




}
