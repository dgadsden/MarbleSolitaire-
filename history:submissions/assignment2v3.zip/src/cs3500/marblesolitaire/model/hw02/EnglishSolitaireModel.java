package cs3500.marblesolitaire.model.hw02;

/**
 * Class that represents the model of a marble solitaire game. A marble solitaire game has arm
 * thickness as well as a empty slot position.
 */
public class EnglishSolitaireModel implements MarbleSolitaireModel {
  //row of empty slot
  private final int sRow;
  //column of empty slot
  private final int sCol;
  // arm thickness(board size)
  private int armThickness;

  private SlotState[][] board;

  static int SIZE;

  /**
   * Default constructor that set arm thickness at 3 and the empty slot in the middle(3,3).
   */
  public EnglishSolitaireModel() {
    this.armThickness = 3;
    SIZE = (3 * armThickness) - 2;
    this.armThickness = 3;
    this.sRow = SIZE / 2;
    this.sCol = SIZE / 2;
    this.board = buildBoard(SIZE);

    if (isInvalid(this.sRow, this.sCol) || isOutOfBounds(this.sRow, this.sCol)) {
      throw new IllegalArgumentException("Invalid empty cell position (" + sRow + "," + sCol + ")");
    } else {
      this.board[this.sRow][this.sCol] = SlotState.Empty;
    }

  }


  /**
   * Constructor has a set arm thickness that takes in position of empty slot.
   *
   * @param sRow the row position on the Marble Solitaire board.
   * @param sCol the column position on the Marble Solitaire board.
   */
  public EnglishSolitaireModel(int sRow, int sCol) {


    this.sRow = sRow;
    this.sCol = sCol;

    SIZE = (3 * armThickness) - 2;

    this.armThickness = 3;
    this.board = buildBoard(SIZE);

    // if the position of the row or col of the empty slot is not odd or is off the board
    // (negative or invalid) an exception is thrown
    if (isInvalid(this.sRow, this.sCol) || isOutOfBounds(this.sRow, this.sCol)) {
      throw new IllegalArgumentException("Invalid empty cell position (" + sRow + "," + sCol + ")");
    } else {
      this.board[sRow][sCol] = SlotState.Empty;
    }


  }


  /**
   * Constructor that takes a given arm thickness and has a set empty slot position at the middle of
   * the board.
   *
   * @param armThickness the arm thickness of the Marble Solitaire board.
   */
  public EnglishSolitaireModel(int armThickness) {

    SIZE = (3 * armThickness) - 2;

    // if the arm thickness is not odd or is off the board
    // (negative or invalid) an exception is thrown
    if (armThickness % 2 == 0 || armThickness <= 0) {
      throw new IllegalArgumentException("Invalid arm thickness.");
    }

    this.armThickness = armThickness;
    this.sRow = SIZE / 2;
    this.sCol = SIZE / 2;

    this.board = buildBoard(SIZE);
    this.board[this.sRow][this.sCol] = SlotState.Empty;

  }


  /**
   * Constructor that takes a given arm thickness and has a set empty slot position at the middle of
   * the board.
   *
   * @param armThickness the arm thickness of the Marble Solitaire board.
   * @param sRow         the row position on the Marble Solitaire board.
   * @param sCol         the column  position on the Marble Solitaire board.
   */
  public EnglishSolitaireModel(int armThickness, int sRow, int sCol) {

    SIZE = (3 * armThickness) - 2;
    
    this.armThickness = armThickness;
    this.sRow = sRow;
    this.sCol = sCol;
    this.board = buildBoard(SIZE);
    this.board[this.sRow][this.sCol] = SlotState.Empty;

    // if the arm thickness is not odd or is off the board
    // (negative) an exception is thrown
    if (armThickness % 2 == 0 || armThickness <= 0) {
      throw new IllegalArgumentException("Invalid arm thickness.");
    }
    // if the position of the row or col of the empty slot is not odd or is off the board
    // (negative) an exception is thrown
    else if (isOutOfBounds(this.sRow, this.sCol) || isInvalid(this.sRow, this.sCol)) {
      throw new IllegalArgumentException("Invalid empty cell position (" + sRow + "," + sCol + ")");
    }


  }

  @Override
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws IllegalArgumentException {
    if (!(vaildMove(fromRow, fromCol, toRow, toCol))) {
      throw new IllegalArgumentException("Invalid move.");
    }
    this.board[toRow][toCol] = SlotState.Marble;
    this.board[fromRow][fromCol] = SlotState.Empty;
    this.board[(fromRow + toRow) / 2][(fromCol + toCol) / 2] = SlotState.Empty;
  }

  @Override
  public boolean isGameOver() {
    for (int i = 0; i < this.getBoardSize(); i++) {
      for (int j = 0; j < this.getBoardSize(); j++) {
        if (this.getSlotAt(i, j).equals(SlotState.Marble)) {
          if ((i - 2 >= 0 && this.vaildMove(i, j, i - 2, j))
                  || (i + 2 < this.getBoardSize() && this.vaildMove(i, j, i + 2, j))
                  || (j - 2 >= 0 && this.vaildMove(i, j, i, j - 2))
                  || (j + 2 < this.getBoardSize() && this.vaildMove(i, j, i, j + 2))) {
            return false;
          }
        }
      }
    }
    return true;
  }

  //tested
  @Override
  public int getBoardSize() {
    return (3 * armThickness) - 2;
  }

  //tested
  @Override
  public SlotState getSlotAt(int row, int col) throws IllegalArgumentException {
    if (isOutOfBounds(row, col)) {
      throw new IllegalArgumentException("Invalid position.");
    } else {
      return this.board[row][col];
    }
  }

  @Override
  public int getScore() {
    int counter = 0;
    for (int i = 0; i < getBoardSize(); i++) {
      for (int j = 0; j < getBoardSize(); j++) {
        switch (getSlotAt(i, j)) {
          case Marble:
            counter += 1;
            break;
          case Empty:
            counter += 0;
            break;
          case Invalid:
            counter += 0;
            break;
          default:
            throw new IllegalArgumentException("invalid");
        }
      }
    }
    return counter;
  }

  private SlotState[][] buildBoard(int boardSize) {
    try {
      board = new SlotState[boardSize][boardSize];
    } catch (NegativeArraySizeException n) {
      n.getMessage();
    }
    for (int i = 0; i < boardSize; i++) {
      for (int j = 0; j < boardSize; j++) {
        if (isInvalid(i, j)) {
          this.board[i][j] = SlotState.Invalid;
        } else {
          this.board[i][j] = SlotState.Marble;
        }
      }
    }
    return board;
  }


  private boolean isInvalid(int row, int col) {
    return ((row < this.armThickness - 1 && col < this.armThickness - 1)
            || (row < this.armThickness - 1 && col > SIZE - this.armThickness)
            || (row > SIZE - this.armThickness && col < this.armThickness - 1)
            || (row > SIZE - this.armThickness && col > SIZE - this.armThickness));
  }

  private boolean isOutOfBounds(int row, int col) {
    return (row < 0 || row > SIZE - 1 || col < 0 || col > SIZE - 1);
  }

  private boolean vaildMove(int fromRow, int fromCol, int toRow, int toCol) {
    return ((!(isOutOfBounds(fromRow, fromCol) && isOutOfBounds(toRow, toCol)))
            && !(getSlotAt(fromRow, fromCol).equals(SlotState.Invalid))
            && !(getSlotAt(toRow, toCol).equals(SlotState.Invalid))
            && getSlotAt(fromRow, fromCol).equals(SlotState.Marble)
            && getSlotAt(toRow, toCol).equals(SlotState.Empty)
            && getSlotAt(((fromRow + toRow) / 2), ((fromCol + toCol) / 2)).equals(SlotState.Marble)
            && ((Math.abs(fromCol - toCol) == 2 && (Math.abs(fromRow - toRow) == 0))
            || ((Math.abs(fromCol - toCol) == 0 && (Math.abs(fromRow - toRow) == 2)))));

  }
}
