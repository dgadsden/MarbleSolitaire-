package cs3500.marblesolitaire.view;

import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * class for the textual representation of a marble solitaire model's board.
 */
public class MarbleSolitaireTextView implements MarbleSolitaireView {

  private MarbleSolitaireModelState board;
  private Appendable appendable;

  /**
   * Constructor that takes in a MarbleSolitaireModelState so that it can be viewed. Prints in
   * System.out.
   *
   * @param board the board of a Marble Solitaire game.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState board) {
    if (board == null) {
      throw new IllegalArgumentException("Given null model.");
    }
    this.board = board;
    this.appendable = System.out;
  }

  /**
   * Constructor that takes in a MarbleSolitaireModelState and Appendable and adds the results to
   * an appendable.
   *
   * @param board      the board or model of a Marble Solitaire.
   * @param appendable used to set the text view of the board.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState board, Appendable appendable) {

    if (board == null || appendable == null) {
      throw new IllegalArgumentException("Given null model or appendable.");
    }

    this.board = board;
    this.appendable = appendable;

  }

  /**
   * Function that turns a MarbleSolitaireModelState Board into string for viewing purposes.
   *
   * @return the board as a string.
   */
  public String toString() {
    StringBuilder view = new StringBuilder();
    for (int i = 0; i < board.getBoardSize(); i++) {
      for (int j = 0; j < board.getBoardSize(); j++) {
        if (board.getSlotAt(i, j).equals(MarbleSolitaireModelState.SlotState.Invalid)) {
          view.append(" ");
        } else if (board.getSlotAt(i, j).equals(MarbleSolitaireModelState.SlotState.Marble)) {
          view.append("O");
        } else if (board.getSlotAt(i, j).equals(MarbleSolitaireModelState.SlotState.Empty)) {
          view.append("_");
        }
        if ((j == board.getBoardSize() - 1 || board.getSlotAt(i, j + 1)
                == MarbleSolitaireModelState.SlotState.Invalid)
                && board.getSlotAt(i, j) != MarbleSolitaireModelState.SlotState.Invalid) {
          view.append("\n");
          break;
        } else {
          view.append(" ");
        }
      }
    }
    if (view.length() > 0) {
      return view.substring(0, view.length() - 1);
    } else {
      return view.substring(0, view.length());
    }
  }

  @Override
  public void renderBoard() throws IOException {
    try {
      this.appendable.append(this.toString());
    } catch (IOException e) {
      throw new IllegalStateException("Something went wrong while writing to the appendable.");
    }
  }

  @Override
  public void renderMessage(String message) throws IOException {
    try {
      this.appendable.append(message);
    } catch (IOException e) {
      throw new IllegalStateException("Something went wrong while writing to the appendable.");
    }
  }
}
